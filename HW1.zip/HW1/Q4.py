
if __name__ == '__main__':
    n = input('enter n');
    print(['Chapter '+str(x+1) for x in range(int(n))])